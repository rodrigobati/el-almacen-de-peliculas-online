package unrn.dto;

import java.util.UUID;

public record ActorDTO(
                String id,
                String name) {
}