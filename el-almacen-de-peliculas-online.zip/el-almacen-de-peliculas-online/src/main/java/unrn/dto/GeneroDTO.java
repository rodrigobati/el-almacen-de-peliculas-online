package unrn.dto;

public record GeneroDTO(
        String id,
        String name,
        String description
) {
}