package unrn.dto;

import java.util.UUID;

public record DirectorDTO(
                String id,
                String name) {
}